===== WeDesignTech Elementor Addon =====

WeDesignTech Elementor Addon plugin adds additional modules for Elementor plugin.


== Changelog ==

= 1.0.6 =

    * Compatible with the latest Elementor Version

= 1.0.5 =

    * Notice error fixed
    * Elementor Loading issue fixed

= 1.0.4 =

    * Fixed: Mailchimp and Header issue 
    * Fixed: Deprecated and warnings errors  

= 1.0.3 =

    * Fixed: Warnings and Deprecated errors
    * Compatible with the latest Elementor Version

= 1.0.2 =

    * Compatible : Latest Elementor Version

= 1.0.1 =

    * Fixed: Elementor deprecated error

= 1.0.0 =

    * First release!