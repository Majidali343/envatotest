======= Neytri Plus =====

Neytri Plus plugin adds additonal features for Neytri theme.


== Changelog ==

= 1.0.6 =

  * Fixed: Deprecated Errors

= 1.0.5 =

  * Notice error fixed

= 1.0.4 =

  * Loader error fixed
    
= 1.0.3 =

  * Walker menu fixed 

= 1.0.2 =

  * Walker menu fixed 
  * Deprecated Errors Fixed

= 1.0.1 =

  * Importer error fixed 

= 1.0.0 =

    * First release!