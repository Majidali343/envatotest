===== Neytri Shop =====

Neytri Shop plugin adds shop features for Neytri theme.


== Changelog ==

= 1.0.2 =

    * Notice Error fixed

= 1.0.1 =

    * Deprecated Errors Fixed

= 1.0.0 =

    * First release!