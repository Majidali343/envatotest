<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.

CSFramework::instance( array(), array() );