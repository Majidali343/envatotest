<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<!-- Entry Tags -->
<div class="single-entry-tags"><span><?php echo esc_html__('Tags', 'neytri-pro');?></span><?php the_tags( '', ' ', '' ); ?></div><!-- Entry Tags -->