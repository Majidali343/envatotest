var dtSizeGuideInit = function() {

    // Product Size Guide

    jQuery('body').on('click', '.wcsg_btn_wrapper .wdt-wcsg-button:not(.disabled)', function (e) {
        e.preventDefault();
    
        var this_item = jQuery(this);
        var product_id = this_item.attr('data-product_id');
        var sizeguide_nonce = this_item.attr('data-sizeguide-nonce');
    
        if (this_item.hasClass('disabled')) {
            return;
        }

        jQuery.ajax({
            type: "POST",
            url: wdtShopObjects.ajaxurl,
            data: {
                action: 'neytri_shop_size_guide_popup',
                product_id: product_id,
                sizeguide_nonce: sizeguide_nonce
            },
            beforeSend: function () {
                this_item.parents('.wcsg_btn_wrapper').append('<div class="wdt-product-loader"><i class="fa fa-spinner fa-spin"></i></div>');
            },
            success: function (response) {
                if (response.success) {
                    jQuery('body').append(response.data);

                    sizeGuideCarousel();
                } else {
                    console.error('Error:', response.data);
                }
            },
            complete: function () {
                this_item.parents('.wcsg_btn_wrapper').find('.wdt-product-loader').remove();
            }
        });

        this_item.addClass('disabled');
    });

    // Product Size Guide Close

    jQuery('body').on('click', '.wdt-size-guide-popup-close', function (e) {
        e.preventDefault();
        jQuery(this).closest('.wdt-size-guide-popup-holder').remove();
        jQuery('.wcsg_btn_wrapper .wdt-wcsg-button').removeClass('disabled');
    });


    // Carousel

    function sizeGuideCarousel() {
        jQuery('.wdt-size-guide-popup-container.swiper-container').each(function () {
            var $swiperItem = jQuery(this);
    
            new Swiper($swiperItem[0], {
                initialSlide: 0,
                simulateTouch: true,
                roundLengths: true,
                grabCursor: true,
                slidesPerView: 1,
                mousewheel: true,
                direction: 'horizontal',
                pagination: {
                    el: $swiperItem.find('.wdt-products-bullet-pagination')[0],
                    type: 'bullets',
                    clickable: true
                }
            });
        });
    }

};


jQuery.noConflict();
jQuery(document).ready(function($){

    "use strict";

    if ( typeof wdtShopObjects !== 'undefined' ) {
        if(wdtShopObjects.product_template == 'woo-default') {
            dtSizeGuideInit();
        }
    }

});


( function( $ ) {

	var wdtShopSizeGuideJs = function($scope, $){
        dtSizeGuideInit();
	};

    $(window).on('elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/wdt-shop-product-single-summary.default', wdtShopSizeGuideJs);
	});

} )( jQuery );