<?php

/*
* Update Summary - Options Filter
*/

if( ! function_exists( 'neytri_shop_woo_single_summary_options_bn_render' ) ) {
	function neytri_shop_woo_single_summary_options_bn_render( $options ) {

		$options['buy_now'] = esc_html__('Summary Buy Now', 'neytri-pro');
		return $options;

	}
	add_filter( 'neytri_shop_woo_single_summary_options', 'neytri_shop_woo_single_summary_options_bn_render', 10, 1 );

}

/*
* Update Summary - Styles Filter
*/

if( ! function_exists( 'neytri_shop_woo_single_summary_styles_bn_render' ) ) {
	function neytri_shop_woo_single_summary_styles_bn_render( $styles ) {

		array_push( $styles, 'wdt-shop-buy-now' );
		return $styles;

	}
	add_filter( 'neytri_shop_woo_single_summary_styles', 'neytri_shop_woo_single_summary_styles_bn_render', 10, 1 );

}

/*
* Update Summary - Scripts Filter
*/

if( ! function_exists( 'neytri_shop_woo_single_summary_scripts_bn_render' ) ) {
	function neytri_shop_woo_single_summary_scripts_bn_render( $scripts ) {

		array_push( $scripts, 'wdt-shop-buy-now' );
		return $scripts;

	}
	add_filter( 'neytri_shop_woo_single_summary_scripts', 'neytri_shop_woo_single_summary_scripts_bn_render', 10, 1 );

}