<?php
class Neytri_Widget_Tag extends WP_Widget {
	#1.constructor
	function __construct() {
		$widget_options = array(
			'classname'   => 'widget_tag',
			'description' => esc_html__('To display Tag with Limit By items in a widget for Shop filter area.', 'neytri-pro')
		);

        $theme_name =  defined('NEYTRI_THEME_NAME') ? NEYTRI_THEME_NAME : 'Neytri';
		parent::__construct( false, $theme_name . esc_html__(' Shop Tag Filter','neytri-pro'), $widget_options );
	}

	#2.widget input form in back-end
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array(
			'title' => '',
			'count' => ''
		) );

		$title = strip_tags($instance['title']);
		$count = strip_tags($instance['count']);
        ?>
        <p>
        	<label for="<?php echo esc_attr($this->get_field_id('title')); ?>">
        		<?php esc_html_e('Title:','neytri-pro');?>
        		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>"/>
			</label>
		</p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('count')); ?>">
        		<?php esc_html_e('Count:','neytri-pro');?>
        		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('count')); ?>" name="<?php echo esc_attr($this->get_field_name('count')); ?>" type="text" value="<?php echo esc_attr($count); ?>"/>
			</label>
        </p>
        <?php
	}

    #3.processes & saves the twitter widget option
	function update( $new_instance,$old_instance ) {
		$instance = $old_instance;

		$instance['title']      = strip_tags($new_instance['title']);
		$instance['count']      = strip_tags($new_instance['count']);

		return $instance;
	}

	#4.output in front-end
	function widget($args, $instance) {
		extract($args);

		global $post;

		$title = empty($instance['title']) ? '' : strip_tags($instance['title']);
		$count = (int) $instance['count'];

        echo neytri_pro_before_after_widget( $before_widget );

        if( !empty( $title ) ) {
			echo neytri_pro_widget_title( $before_title . $title . $after_title );
		}

        $the_query = new WP_Query($args);

        $orderby = 'name';
        $order = 'asc';
        $hide_empty = false;
        $cat_args = array(
            'orderby'    => $orderby,
            'order'      => $order,
            'hide_empty' => $hide_empty
        );
        
        $product_tags = get_terms( 'product_tag', $cat_args );

        if( !empty($product_tags) ){
            echo '
            <div class="widget-tag-filter">
            <ul>';
                foreach ($product_tags as $key => $tag) {
                    if( $key < $count ) {
						echo '<li>';
                        echo '<a href="'.get_term_link($tag).'" >';
                        esc_html_e($tag->name);
                        echo '</a>';
                        echo '</li>';

						if($key == $count) {
							break;
						}
                    }
                }
            echo '</ul></div>';
        }

        echo neytri_pro_before_after_widget( $after_widget );
		
	}
}?>