<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<!-- Entry Content -->
<div class="single-entry-excerpt">
	<?php the_excerpt();?>
</div><!-- Entry Content -->