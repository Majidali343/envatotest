<?php

/*
* Update Summary - Options Filter
*/

if( ! function_exists( 'neytri_shop_woo_single_summary_options_cneytri_render' ) ) {
	function neytri_shop_woo_single_summary_options_cneytri_render( $options ) {

		$options['countdown'] = esc_html__('Summary Count Down', 'neytri-pro');
		return $options;

	}
	add_filter( 'neytri_shop_woo_single_summary_options', 'neytri_shop_woo_single_summary_options_cneytri_render', 10, 1 );

}

/*
* Update Summary - Styles Filter
*/

if( ! function_exists( 'neytri_shop_woo_single_summary_styles_cneytri_render' ) ) {
	function neytri_shop_woo_single_summary_styles_cneytri_render( $styles ) {

		array_push( $styles, 'wdt-shop-coundown-timer' );
		return $styles;

	}
	add_filter( 'neytri_shop_woo_single_summary_styles', 'neytri_shop_woo_single_summary_styles_cneytri_render', 10, 1 );

}

/*
* Update Summary - Scripts Filter
*/

if( ! function_exists( 'neytri_shop_woo_single_summary_scripts_cneytri_render' ) ) {
	function neytri_shop_woo_single_summary_scripts_cneytri_render( $scripts ) {

		array_push( $scripts, 'jquery-downcount' );
		array_push( $scripts, 'wdt-shop-coundown-timer' );
		return $scripts;

	}
	add_filter( 'neytri_shop_woo_single_summary_scripts', 'neytri_shop_woo_single_summary_scripts_cneytri_render', 10, 1 );

}