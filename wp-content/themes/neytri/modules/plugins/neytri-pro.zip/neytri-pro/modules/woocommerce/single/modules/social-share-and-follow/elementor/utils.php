<?php

/*
* Update Summary Options Filter
*/

if( ! function_exists( 'neytri_shop_woo_single_summary_options_ssf_render' ) ) {
	function neytri_shop_woo_single_summary_options_ssf_render( $options ) {

		$options['share_follow'] = esc_html__('Summary Share / Follow', 'neytri-pro');
		return $options;

	}
	add_filter( 'neytri_shop_woo_single_summary_options', 'neytri_shop_woo_single_summary_options_ssf_render', 10, 1 );

}


/*
* Update Summary - Styles Filter
*/

if( ! function_exists( 'neytri_shop_woo_single_summary_styles_ssf_render' ) ) {
	function neytri_shop_woo_single_summary_styles_ssf_render( $styles ) {

		array_push( $styles, 'wdt-shop-social-share-and-follow' );
		return $styles;

	}
	add_filter( 'neytri_shop_woo_single_summary_styles', 'neytri_shop_woo_single_summary_styles_ssf_render', 10, 1 );

}
