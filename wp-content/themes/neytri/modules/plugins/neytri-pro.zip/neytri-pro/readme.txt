===== Neytri Pro =====

Neytri Pro plugin adds advanced features for Neytri theme.


== Changelog ==

= 1.0.4 =

    * Deprecated Errors Fixed

= 1.0.3 =

    * Deprecated Errors Fixed

= 1.0.2 =

    * Deprecated Errors Fixed

= 1.0.1 =

    * Fixed : Cart Count Issue.

= 1.0.0 =

    * First release!